﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
namespace mouse_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;
        private const int MOUSEEVENTF_RIGHTDOWN = 0x08;
        private const int MOUSEEVENTF_RIGHTUP = 0x10;
        [Flags]
        public enum MouseEventFlags
        {
            LeftDown = 0x00000002,
            LeftUp = 0x00000004,
            MiddleDown = 0x00000020,
            MiddleUp = 0x00000040,
            Move = 0x00000001,
            Absolute = 0x00008000,
            RightDown = 0x00000008,
            RightUp = 0x00000010
        }

        [DllImport("user32.dll", EntryPoint = "SetCursorPos")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetCursorPos(int X, int Y);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetCursorPos(out MousePoint lpMousePoint);

        [DllImport("user32.dll")]
        private static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);

        public static void SetCursorPosition(int X, int Y)
        {
            SetCursorPos(X, Y);
        }

        public static void SetCursorPosition(MousePoint point)
        {
            SetCursorPos(point.X, point.Y);
        }

        public static MousePoint GetCursorPosition()
        {
            MousePoint currentMousePoint;
            var gotPoint = GetCursorPos(out currentMousePoint);
            if (!gotPoint) { currentMousePoint = new MousePoint(0, 0); }
            return currentMousePoint;
        }

        //public static void MouseEvent(MouseEventFlags value)
        //{
        //    MousePoint position = GetCursorPosition();
        //    mouse_event
        //        ((int)value,
        //         position.X,
        //         position.Y,
        //         0,
        //         0)
        //        ;
        //}

        [StructLayout(LayoutKind.Sequential)]
        public struct MousePoint
        {
            public int X;
            public int Y;

            public MousePoint(int x, int y)
            {
                X = x;
                Y = y;
            }

        }
        char on = '0';
        int s1, s2;
        int n1, n2;
        int r1, r2;
        int l1, l2;
        private void button1_Click(object sender, EventArgs e)
        {
            if (on == '0')
            {
                button1.Text = "Hesssss";
                on = '1';
                timer1.Interval = Convert.ToInt32(textBox1.Text) * 1000;
                timer2.Interval = Convert.ToInt32(textBox2.Text) * 1000;
                timer3.Interval = Convert.ToInt32(textBox3.Text) * 900;
                s1 = Convert.ToInt32(textBox4.Text)*34;
                s2 = 768-(Convert.ToInt32(textBox5.Text)*33);
                n1 = Convert.ToInt32(textBox6.Text)*34;
                n2 = 768-(Convert.ToInt32(textBox7.Text)*33);
                r1 = Convert.ToInt32(textBox8.Text)*34;
                r2 = 768-(Convert.ToInt32(textBox9.Text)*33);
                l1 = Convert.ToInt32(textBox10.Text)*34;
                l2 = 768-(Convert.ToInt32(textBox11.Text)*33);
                timer1.Start();
            }
            else if (on == '1')
            {
                button1.Text = "START YA M3LEM";
                on = '0';
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
                timer4.Stop();
            }
          

        }
        Random R = new Random();
        int ch = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            SetCursorPosition(s1, s2);
            timer2.Start();
            MousePoint position = GetCursorPosition();
            mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, position.X, position.Y, 0, 0);
            ch = R.Next(1, 3);
        }
        

        int i = 0;
        int t = 0;
        int f = 255;
       
        private void timer2_Tick(object sender, EventArgs e)
        {
            //
            timer2.Interval = 1000;
            if (ch == 1)
            {
                t = R.Next(1, 6);                                
                if (i == 1)
                {                    
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);                   
                }
                else if (i == 2)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                else if (i == 3)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 4)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 5)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                i++;
            }
            else if (ch == 2)
            {
                t = R.Next(1, 8);
                if (i == 1)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                else if (i == 2)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 3)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 4)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 5)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                i++;
            }
            else if (ch == 3)
            {
                t = R.Next(1, 8);
                if (i == 1)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                else if (i == 2)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                else if (i == 3)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1,l2);
                }
                else if (i == 4)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 5)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                i++;
            }
            else if (ch == 4)
            {
                t = R.Next(1, 8);
                if (i == 1)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                else if (i == 2)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                else if (i == 3)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                else if (i == 4)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 5)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                i++;
            }
            else if (ch == 5)
            {
                t = R.Next(1, 8);
                if (i == 1)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                else if (i == 2)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                else if (i == 3)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 4)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                else if (i == 5)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                i++;
            }
            else if (ch == 6)
            {
                t = R.Next(1, 8);
                if (i == 1)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 2)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 3)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 4)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1,l2);
                }
                else if (i == 5)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                i++;
            }
            else if (ch == 7)
            {
                t = R.Next(1, 8);
                if (i == 1)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(r1, r2);
                }
                else if (i == 2)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 3)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if (i == 4)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                else if(i == 5)
                {
                    timer2.Interval += (t * f);
                    SetCursorPosition(l1, l2);
                }
                i++;
            }
            MousePoint position = GetCursorPosition();
            mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, position.X, position.Y, 0, 0);
            if (i == 6)
            {
                timer3.Start();
                timer2.Stop();
                i = 0;
            }
            else
            {
                timer2.Stop();
                timer2.Start();
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            
            timer3.Stop();
            SetCursorPosition(n1, n2);
            timer4.Start();
            MousePoint position = GetCursorPosition();
            mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, position.X, position.Y, 0, 0);
        }

        private void timer4_Tick_1(object sender, EventArgs e)
        {
            timer4.Stop();
            SetCursorPosition(n1, n2);
            timer1.Start();
            MousePoint position = GetCursorPosition();
            mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, position.X, position.Y, 0, 0);
        }
    }
}
